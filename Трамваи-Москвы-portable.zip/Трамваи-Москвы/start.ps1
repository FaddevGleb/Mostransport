﻿# Portable static server for the tram map. No install required.
$ErrorActionPreference = "Stop"
$root = (Resolve-Path -LiteralPath (Split-Path -Parent $MyInvocation.MyCommand.Path)).Path
if (-not $root.EndsWith("\")) { $root = $root + "\" }

$mime = @{
  ".html" = "text/html; charset=utf-8"
  ".css" = "text/css; charset=utf-8"
  ".js" = "text/javascript; charset=utf-8"
  ".json" = "application/json; charset=utf-8"
  ".geojson" = "application/geo+json; charset=utf-8"
  ".png" = "image/png"
  ".woff2" = "font/woff2"
  ".woff" = "font/woff"
  ".ttf" = "font/ttf"
  ".csv" = "text/csv; charset=utf-8"
  ".txt" = "text/plain; charset=utf-8"
  ".md" = "text/plain; charset=utf-8"
  ".py" = "text/plain; charset=utf-8"
  ".zip" = "application/zip"
  ".svg" = "image/svg+xml"
}

$listener = $null
$port = 0
foreach ($candidate in 8765..8775) {
  $tryListener = New-Object System.Net.HttpListener
  $tryListener.Prefixes.Add("http://localhost:$candidate/")
  try {
    $tryListener.Start()
    $listener = $tryListener
    $port = $candidate
    break
  } catch {
    $tryListener.Close()
  }
}

if (-not $listener) {
  Write-Host "Не удалось открыть порт 8765-8775."
  exit 1
}

$url = "http://localhost:$port/"
Write-Host ""
Write-Host "Трамваи Москвы — портативная версия"
Write-Host "Адрес: $url"
Write-Host "Окно можно не закрывать: оно и есть сервер. Остановка — Ctrl+C или крестик."
Write-Host ""
Start-Process $url

try {
  while ($listener.IsListening) {
    $context = $listener.GetContext()
    $response = $context.Response
    try {
      $relative = [Uri]::UnescapeDataString($context.Request.Url.LocalPath)
      if ([string]::IsNullOrWhiteSpace($relative) -or $relative -eq "/") { $relative = "/index.html" }
      $relative = $relative.TrimStart("/") -replace "/", [IO.Path]::DirectorySeparatorChar
      $full = [IO.Path]::GetFullPath((Join-Path $root $relative))
      if (-not $full.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) {
        $response.StatusCode = 403
      } elseif (Test-Path -LiteralPath $full -PathType Leaf) {
        $bytes = [IO.File]::ReadAllBytes($full)
        $ext = [IO.Path]::GetExtension($full).ToLowerInvariant()
        $type = $mime[$ext]
        if (-not $type) { $type = "application/octet-stream" }
        $response.ContentType = $type
        $response.ContentLength64 = $bytes.Length
        $response.OutputStream.Write($bytes, 0, $bytes.Length)
      } else {
        $response.StatusCode = 404
      }
    } catch {
      try { $response.StatusCode = 500 } catch {}
    } finally {
      try { $response.OutputStream.Close() } catch {}
    }
  }
} finally {
  $listener.Stop()
  $listener.Close()
}

/* global window */
const TramDemand = (() => {
  const DISTRICTS = [
    ["Хамовники", "Облачно", 13, 4, 20],
    ["Якиманка", "Небольшой дождь", 12, 5, 70],
    ["Сокольники", "Пасмурно", 11, 3, 35],
    ["Преображенское", "Облачно", 12, 4, 25],
    ["Лефортово", "Дождь", 11, 6, 80],
    ["Даниловский", "Переменная облачность", 13, 4, 15],
    ["Чертаново Южное", "Ясно", 14, 3, 5],
    ["Останкинский", "Облачно", 12, 5, 30],
    ["Щукино", "Пасмурно", 11, 4, 40],
    ["Северное Медведково", "Морось", 10, 5, 55],
    ["Сокол", "Облачно", 12, 3, 20],
    ["Новогиреево", "Ясно", 14, 2, 0],
  ].map(([name, condition, temp, wind, rain]) => ({ name, condition, temp, wind, rain }));

  function hash(value) {
    let result = 2166136261;
    const text = String(value);
    for (let index = 0; index < text.length; index += 1) {
      result ^= text.charCodeAt(index);
      result = Math.imul(result, 16777619);
    }
    return result >>> 0;
  }

  function mix(seed) {
    const value = Math.sin(seed) * 10000;
    return value - Math.floor(value);
  }

  function profile(seed, hour, dayOffset) {
    const date = new Date();
    date.setDate(date.getDate() + dayOffset);
    const weekend = date.getDay() === 0 || date.getDay() === 6;
    const commute = (hour >= 7 && hour <= 10) || (hour >= 17 && hour <= 20);
    const night = hour < 6 || hour >= 23;
    const shape = night ? 0.22 : commute ? 1.05 : 0.68;
    const noise = 0.8 + mix(seed + hour * 19 + dayOffset * 53) * 0.45;
    const pressure = 0.48 + mix(seed + 11) * 0.95;
    const capacity = 900 + (seed % 1700);
    const passengers = Math.max(40, Math.round(capacity * shape * noise * pressure * (weekend ? 0.76 : 1)));
    return { hour, passengers, load: passengers / capacity, capacity };
  }

  function dayBlock(seed, dayOffset) {
    const hours = Array.from({ length: 24 }, (_, hour) => profile(seed, hour, dayOffset));
    const peak = hours.reduce((best, item) => (item.load > best.load ? item : best), hours[0]);
    const date = new Date();
    date.setDate(date.getDate() + dayOffset);
    return {
      label: date.toLocaleDateString("ru-RU", { weekday: "long", day: "numeric", month: "short" }),
      hours,
      total: hours.reduce((sum, item) => sum + item.passengers, 0),
      peak,
    };
  }

  function demandFor(routeKey) {
    const seed = hash(routeKey);
    const today = dayBlock(seed, 0);
    const tomorrow = dayBlock(seed, 1);
    const hourNow = new Date().getHours();
    const upcoming = Array.from({ length: 12 }, (_, shift) => {
      const dayOffset = Math.floor((hourNow + shift) / 24);
      return profile(seed, (hourNow + shift) % 24, dayOffset);
    });
    const peak = upcoming.reduce((best, item) => (item.load > best.load ? item : best), upcoming[0]);
    return {
      capacity: today.hours[0].capacity,
      current: today.hours[hourNow],
      upcoming,
      index: peak.load,
      today: today.hours.filter((item) => item.hour >= hourNow),
      tomorrow,
      laterDays: Array.from({ length: 6 }, (_, index) => dayBlock(seed, index + 2)),
    };
  }

  function loadTone(load) {
    if (load > 1) return "hot";
    if (load >= 0.8) return "warm";
    return "ok";
  }

  function formatLoad(load) {
    return `${Math.round(load * 100)}%`;
  }

  function formatPassengers(value) {
    return Math.round(value).toLocaleString("ru-RU");
  }

  function formatHour(hour) {
    return `${String(hour).padStart(2, "0")}:00`;
  }

  return { DISTRICTS, demandFor, loadTone, formatLoad, formatPassengers, formatHour };
})();

window.TramDemand = TramDemand;
